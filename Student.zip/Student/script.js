$('#example').DataTable({
    responsive: true
});